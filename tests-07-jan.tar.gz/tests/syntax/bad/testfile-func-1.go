package main
func foo(,) {}

